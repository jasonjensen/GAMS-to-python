DEBUGATOR, version 2, July 2016

*==============================================================================*
*                                                                              *
*           Except where otherwise noted, this work is licensed under          *
*               http://creativecommons.org/licenses/by-nc-sa/3.0/              *
*                                                                              *
*                                                                              *
*  You are free to share, to copy, distribute and transmit the work under      *
*  the following conditions:                                                   *
*                                                                              *
*  - Attribution:         You must attribute the work to:                      *
*                         Helene Maisonnave, Bernard Decaluwe                  *
*                         V�ronique Robichaud and Andr� Lemelin.               *
*  - Noncommercial:       You may not use this work for commercial purposes.   *
*  - Share Alike:         If you alter, transform, or build upon this work,    *
*                         you may distribute the resulting work only under     *
*                         the same or similar license to this one.             *
*                                                                              *
*==============================================================================*

This zip file has been downloaded from:
www.pep-net.org/pep-standard-cge-models

--------------------------------------------------------------------------------
This document provides some hints on how to debug a Computable General Equilibrium 
(CGE) model written in GAMS.The aim is to provide a method to help the readers 
debug their own errors, whatever the model used. The document tries to be 
systematic and pedagogical. The model used for all the applications is 
PEP1-1-v2_1, available online at https://www.pep-net.org/pep-standard-cge-models. 
Errors have been deliberately introduced in the model GAMS codes. The reader can 
try to find them by him/herself and then compare with the document if necessary. 
The errors are a sample of the type of mistakes that may be encountered while 
running the GAMS code, such as compilation errors, execution, calibration and 
specification errors. This document, however, is not an exhaustive list of all 
the different problems that may be encountered. The intention is to guide the 
reader on how to debug his or her code using hypothetical examples.
--------------------------------------------------------------------------------

Good luck!

The PEP modeling team

PEP-1-1, version 2.1, July 2013

*==============================================================================*
*                                                                              *
*           Except where otherwise noted, this work is licensed under          *
*               http://creativecommons.org/licenses/by-nc-sa/3.0/              *
*                                                                              *
*                                                                              *
*  You are free to share, to copy, distribute and transmit the work under      *
*  the following conditions:                                                   *
*                                                                              *
*  - Attribution:         You must attribute the work to:                      *
*                         Veronique Robichaud, Andre Lemelin,                  *
*                         Helene Maisonnave and Bernard Decaluwe.              *
*  - Noncommercial:       You may not use this work for commercial purposes.   *
*  - Share Alike:         If you alter, transform, or build upon this work,    *
*                         you may distribute the resulting work only under     *
*                         the same or similar license to this one.             *
*                                                                              *
*==============================================================================*

This zip file has been downloaded from:
www.pep-net.org/pep-standard-cge-models

It contains all the necessary programs to run the PEP-1-1 standard 
single-country static CGE model, together with the relevant documentation.

When you unzip the downloaded file, il will create 4 folders:
- user_guide
- presentation
- debugator
- GAMS_code

================================================================================
---PEP-1-1 Model documentation--------------------------------------------------
================================================================================

Folder "user_guide":
- PEP-1-1_v2_1.pdf: this is the detailed description of the model:
   DECALUW�, Bernard, Andr� LEMELIN, V�ronique ROBICHAUD and H�l�ne MAISONNAVE (2013), 
   PEP-1-1. The PEP standard single-country, static CGE model (Version 2.1), 
   Partnership for Economic Policy (PEP) Research Network, Universit� Laval, Qu�bec.	

- PEP 1-1 User Guide.pdf: this Guide is more directly focused on applying the
  model, and in particular on how to configure a country SAM. Be advised, however,
  that the Guide was elaborated on the basis of a previous version of PEP-1-1.

   V�ronique ROBICHAUD, Andr� LEMELIN, H�l�ne MAISONNAVE and Bernard DECALUW� (2012), 
   PEP-1-1. A User Guide, Partnership for Economic Policy (PEP) Research Network, 
   Universit� Laval, Qu�bec and IFPRI-AGRODEP.

--------------------------------------------------------------------------------
Folder "presentation":
This folder contains presentations of version 2.0 of the PEP-1-1 model.
While the presentations are not perfectly up-to-date, we believe that they are 
nonetheless useful as an initiation to PEP-1-1.
- PEP 1-1.ppsx:
   A slide-show presentation of the model by V�ronique ROBICHAUD,
   Andr� LEMELIN, H�l�ne MAISONNAVE and Bernard DECALUW� (2012), elaborated 
   thanks to a joint effort by IFPRI and PEP in the context of AGRODEP, with
   financial support from AGRODEP.

- PEP 1-1-SlidesNotes.pdf:
   A pdf document which reproduces the slides in PEP 1-1.ppsx, together with
   presentation notes

--------------------------------------------------------------------------------
Folder "debugator": 
This folder contains a document that provides hints on how to debug a CGE model 
written in GAMS. The error examples are constructed using the PEP 1-1_v2_1 model,
but the method could be applied to any other CGE. The reader is invited to solve
the errors in the Zip file before checking the solution in the pdf.  

- DEBUGATOR_v2_2016.pdf:
   MAISONNAVE, H�l�ne, Bernard DECALUW�, V�ronique ROBICHAUD and Andr� LEMELIN (2016), 
   Debugator. How to debug a computable general equilibrium model using GAMS, 
   Partnership for Economic Policy (PEP) Research Network, Universit� Laval, 
   Qu�bec and IFPRI-AGRODEP.

- GAMS_files_with_errors_Debugator.zip:
   Includes 20 GAMS files that accompany DEBUGATOR.pdf.

================================================================================
---Files to run the PEP-1-1 model-----------------------------------------------
================================================================================

Folder "GAMS_code"

- PEP-1-1_v2_1.gms is the model GAMS code. 

- PEP-1-1_v2_1_slack.gms is the same as PEP-1-1_v2_1.gms but it computes slack 
  variables for the redundant equations that have been deleted from the model to
  make it square. The slack variables should all be zero.

- VAL_PAR.xls is an Excel file of model parameters.

- SAM-V2_0.xls is an Excel file containing the social accounting matrix (SAM) of
  a fictitious country, to illustrate how the model works.

- RESULTS PEP 1-1.gms is called by the main program to produce results files. 
  Note that in PEP-1-1_v2_1.gms, the model is solved only once: the reference 
  solution is given by the SAM. If the model is run without any simulation 
  constraints or parameter changes, the results should be identical to the 
  reference solution.

--------------------------------------------------------------------------------
For further details, please refer to the comments in the GAMS programs and to 
the included model documentation 

The PEP modeling team
